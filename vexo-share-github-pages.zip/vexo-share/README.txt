VEXO SHARE — GitHub Pages + Supabase

1. In Supabase Storage, create a PRIVATE bucket named:
   vexo-files

2. Open Supabase SQL Editor and run:
   setup.sql

3. Upload these files to the ROOT of your GitHub Pages repository:
   index.html
   share.html

4. Enable GitHub Pages for the repository using the root folder.

The frontend uses the Supabase publishable key. Do NOT replace it with a secret/service-role key.

Notes:
- Anonymous users can create shares.
- Files are stored in a private bucket.
- Shares expire and may have download limits.
- Signed URLs are generated for 120 seconds.
- Expired objects are not automatically deleted by this first version. A later cleanup job can remove them.
