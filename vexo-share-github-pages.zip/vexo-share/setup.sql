-- Vexo Share: database + security setup
-- Run this in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.shares (
  id uuid primary key default gen_random_uuid(),
  share_code text not null unique,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  max_downloads integer,
  download_count integer not null default 0,
  check (length(share_code) between 8 and 32),
  check (expires_at > created_at),
  check (max_downloads is null or max_downloads > 0),
  check (download_count >= 0)
);

create table if not exists public.share_files (
  id uuid primary key default gen_random_uuid(),
  share_id uuid not null references public.shares(id) on delete cascade,
  file_name text not null,
  storage_path text not null unique,
  file_size bigint not null default 0,
  mime_type text,
  created_at timestamptz not null default now(),
  check (length(file_name) between 1 and 255),
  check (file_size >= 0)
);

create index if not exists shares_code_idx on public.shares(share_code);
create index if not exists shares_expiry_idx on public.shares(expires_at);
create index if not exists share_files_share_idx on public.share_files(share_id);

alter table public.shares enable row level security;
alter table public.share_files enable row level security;

revoke all on table public.shares from anon, authenticated;
revoke all on table public.share_files from anon, authenticated;

grant select, insert on public.shares to anon;
grant select, insert on public.share_files to anon;

-- Visitors may only read active shares.
drop policy if exists "anon_read_active_shares" on public.shares;
create policy "anon_read_active_shares"
on public.shares
for select
to anon
using (
  expires_at > now()
  and (max_downloads is null or download_count < max_downloads)
);

-- Visitors may create shares with reasonable bounds.
drop policy if exists "anon_create_shares" on public.shares;
create policy "anon_create_shares"
on public.shares
for insert
to anon
with check (
  length(share_code) between 8 and 32
  and expires_at > now()
  and expires_at <= now() + interval '30 days'
  and (max_downloads is null or (max_downloads > 0 and max_downloads <= 1000))
  and download_count = 0
);

-- File metadata is readable only while its parent share is active.
drop policy if exists "anon_read_active_share_files" on public.share_files;
create policy "anon_read_active_share_files"
on public.share_files
for select
to anon
using (
  exists (
    select 1
    from public.shares s
    where s.id = share_files.share_id
      and s.expires_at > now()
      and (s.max_downloads is null or s.download_count < s.max_downloads)
  )
);

-- A file can only be attached to a share that the same anonymous client just/has created.
drop policy if exists "anon_create_share_files" on public.share_files;
create policy "anon_create_share_files"
on public.share_files
for insert
to anon
with check (
  exists (
    select 1
    from public.shares s
    where s.id = share_files.share_id
      and s.expires_at > now()
  )
);



-- Create the private storage bucket if it does not already exist.
insert into storage.buckets (id, name, public)
values ('vexo-files', 'vexo-files', false)
on conflict (id) do nothing;

-- Storage upload policy: a file must live under the share code it belongs to.
drop policy if exists "anon_upload_vexo_share_files" on storage.objects;
create policy "anon_upload_vexo_share_files"
on storage.objects
for insert
to anon
with check (
  bucket_id = 'vexo-files'
  and (storage.foldername(name))[1] is not null
  and exists (
    select 1
    from public.shares s
    where s.share_code = (storage.foldername(name))[1]
      and s.expires_at > now()
  )
);

-- Storage SELECT policy is used by createSignedUrl. It only permits files whose
-- parent share is still active. The download-count limit is enforced separately
-- by consume_share_download so a generated URL can actually be delivered.
drop policy if exists "anon_read_active_vexo_share_files" on storage.objects;
create policy "anon_read_active_vexo_share_files"
on storage.objects
for select
to anon
using (
  bucket_id = 'vexo-files'
  and exists (
    select 1
    from public.shares s
    where s.share_code = (storage.foldername(name))[1]
      and s.expires_at > now()
  )
);

-- Atomically consume one download. This avoids granting broad UPDATE access.
create or replace function public.consume_share_download(p_share_code text)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  did_update boolean;
begin
  update public.shares
  set download_count = download_count + 1
  where share_code = p_share_code
    and expires_at > now()
    and (max_downloads is null or download_count < max_downloads)
  returning true into did_update;

  return coalesce(did_update, false);
end;
$$;

revoke all on function public.consume_share_download(text) from public;
grant execute on function public.consume_share_download(text) to anon;

